package com.leaftaps.execution;

import org.testng.annotations.Test;

public class MultipleTestNGAttributes {


	@Test (invocationCount = 3, priority = 3)
	public void createLead() {
		System.out.println("Create Lead executed successfully");
	}
	

	@Test (priority = 0, enabled= false)
	public void editLead() {
		System.out.println("Edit Lead executed successfully");
	}
	

	@Test (priority = 1, enabled = true, invocationCount = 5)
	public void mergeLead() {
		System.out.println("Merge Lead executed successfully");
	}
	

	@Test (priority = -1)
	public void deleteLead() {
		System.out.println("Delete Lead executed successfully");
	}
	
	
}
