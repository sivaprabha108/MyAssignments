package com.leaftaps.execution;

import org.testng.annotations.Test;

public class LearnDependsOnMethod5 {


		@Test  ()
		public void createLead() {
			System.out.println("Create Lead executed successfully");
		}
		

		
	}


