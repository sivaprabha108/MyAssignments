package com.leaftaps.execution;

import org.testng.annotations.Test;

public class LearnEnabled {

	@Test (priority = 3)
	public void createLead() {
		System.out.println("Create Lead executed successfully");
	}
	

	@Test (priority = 0)
	public void editLead() {
		System.out.println("Edit Lead executed successfully");
	}
	

	@Test (priority = 1)
	public void mergeLead() {
		System.out.println("Merge Lead executed successfully");
	}
	

	@Test (priority = -5, enabled = false)
	public void deleteLead() {
		System.out.println("Delete Lead executed successfully");
	}
	
	
	
}
