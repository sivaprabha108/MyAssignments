package com.leaftaps.execution;

import org.testng.annotations.Test;

public class LearnDependsOnMethod {

	

		@Test 
		public void createLead() {
			System.out.println("Create Lead executed successfully");
		}
		

		@Test 
		public void editLead() {
			System.out.println("Edit Lead executed successfully");
		}
		

		@Test 
		public void mergeLead() {
			System.out.println("Merge Lead executed successfully");
		}
		

		@Test (dependsOnMethods = "createLead")
		public void deleteLead() {
			System.out.println("Delete Lead executed successfully");
		}

	}


