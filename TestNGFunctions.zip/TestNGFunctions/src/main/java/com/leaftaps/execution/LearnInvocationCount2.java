package com.leaftaps.execution;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LearnInvocationCount2 {

	
	
	@Test (invocationCount = 150)
	public void createLead()  {

		System.out.println("CreateLead executed successfully");
	}
	
}
