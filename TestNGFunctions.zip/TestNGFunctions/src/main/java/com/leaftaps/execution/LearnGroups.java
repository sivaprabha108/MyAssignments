package com.leaftaps.execution;

import org.testng.annotations.Test;

public class LearnGroups {


		@Test  (groups = "smoke")
		public void createLead() {
			System.out.println("Create Lead executed successfully");
		}
		

		@Test  (groups = "functional")
		public void editLead() {
			System.out.println("Edit Lead executed successfully");
		}
		

		@Test  (groups = "regression")
		public void mergeLead() {
			System.out.println("Merge Lead executed successfully");
		}
		

		@Test  (groups = "functional")
		public void deleteLead() {
			System.out.println("Delete Lead executed successfully");
			
		}
		
		@Test  (groups = {"functional", "regression"})
		public void duplicateLead() {
			System.out.println("Duplicate Lead executed successfully");
		}
	}


