package com.leaftaps.execution;

import org.testng.annotations.Test;

public class LearnDependsOnMethod2 {


		@Test  (priority = 2)
		public void createLead() {
			System.out.println("Create Lead executed successfully");
		}
		

		@Test  (priority = 1)
		public void editLead() {
			System.out.println("Edit Lead executed successfully");
		}
		

		@Test   (priority = 0)
		public void mergeLead() {
			System.out.println("Merge Lead executed successfully");
		}
		

		@Test (dependsOnMethods = "createLead", priority = -5)
		public void deleteLead() {
			System.out.println("Delete Lead executed successfully");
		}

	}


