package com.leaftaps.execution;

import org.testng.annotations.Test;

public class LearnDependsOnGroups {


		@Test  (groups = "smoke")
		public void createLead() {
			System.out.println("Create Lead executed successfully");
		}
		

		@Test  (groups = "functional", dependsOnGroups = "smoke")
		public void editLead() {
			System.out.println("Edit Lead executed successfully");
		}
		

		@Test  (groups = "regression", dependsOnGroups = {"smoke", "functional"})
		public void mergeLead() {
			System.out.println("Merge Lead executed successfully");
		}
		

		@Test  (groups = "functional", dependsOnGroups = "smoke")
		public void deleteLead() {
			System.out.println("Delete Lead executed successfully");
			
		}
		
		@Test  (groups = {"functional", "regression"},  dependsOnGroups = {"smoke", "functional"})
		public void duplicateLead() {
			System.out.println("Duplicate Lead executed successfully");
		}
	}


