package com.leaftaps.execution;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LearnInvocationCount {

	@Test (invocationCount = 2)
	public void createLead() throws InterruptedException {

		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		ChromeOptions addArguments = options.addArguments("--remote-allow-origins=*");
		ChromeDriver driver = new ChromeDriver(addArguments);
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.findElement(By.id("username")).sendKeys("Demosalesmanager");
		driver.findElement(By.name("PASSWORD")).sendKeys("crmsfa");
		driver.findElement(By.xpath("//input[@class = \"decorativeSubmit\"]")).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.findElement(By.linkText("CRM/SFA")).click();
		driver.findElement(By.linkText("Leads")).click();
		driver.findElement(By.linkText("Create Lead")).click();
		driver.findElement(By.xpath("//input[@id= \"createLeadForm_companyName\"]")).sendKeys("LearnTestAutomation");
		driver.findElement(By.xpath("//input[@id= \"createLeadForm_firstName\"]")).sendKeys("Bright");
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys("Future");
		WebElement country = driver.findElement(By.id("createLeadForm_generalCountryGeoId"));
		Select countryDD = new Select(country);
		countryDD.selectByVisibleText("India");
		WebElement state = driver.findElement(By.id("createLeadForm_generalStateProvinceGeoId"));
		Select stateDD = new Select(state);
		stateDD.selectByVisibleText("TAMILNADU");
		driver.findElement(By.className("smallSubmit")).click();
		Thread.sleep(2000);
		driver.close();
	}
	
}
