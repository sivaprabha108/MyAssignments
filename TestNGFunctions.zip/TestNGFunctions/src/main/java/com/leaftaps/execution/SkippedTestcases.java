package com.leaftaps.execution;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SkippedTestcases {

	
	@Test 
	public void createLead() {
		
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		ChromeOptions addArguments = options.addArguments("--remote-allow-origins=*");
		ChromeDriver driver = new ChromeDriver(addArguments);
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.findElement(By.id("username123")).sendKeys("Demosalesmanager");
	}
	

	@Test  (dependsOnMethods = "createLead")
	public void editLead() {
		System.out.println("Edit Lead executed successfully");
	}
	

	@Test  (dependsOnMethods = "createLead")
	public void mergeLead() {
		System.out.println("Merge Lead executed successfully");
	}
	

	@Test (dependsOnMethods = {"createLead", "editLead", "mergeLead"}, priority = -5)
	public void deleteLead() {
		System.out.println("Delete Lead executed successfully");
	}
}
