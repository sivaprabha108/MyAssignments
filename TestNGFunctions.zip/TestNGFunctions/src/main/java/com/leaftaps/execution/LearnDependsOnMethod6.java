package com.leaftaps.execution;

import org.testng.annotations.Test;

public class LearnDependsOnMethod6 {

		@Test  (dependsOnMethods = "com.leaftaps.execution.LearnDependsOnMethod5.createLead" )
		public void editLead() {
			System.out.println("Edit Lead executed successfully");
		}
		

		
	}


